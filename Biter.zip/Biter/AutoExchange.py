# ****************************************************************************************************************
#############################基于Gate.io的自动交易软件
#############################版本号V1.0
# ****************************************************************************************************************
################导入所用的库
import ccxt
import requests
import time
import datetime
import pandas as pd

pd.set_option('expand_frame_repr', False)  # 不让它出现省略号
##############*************************************
################设定阈值
limit_chpercent = 1  ##设定每次交易占余额的百分比
buy_down_percent = 0.05  ##当行情低于此价格后进入买入操作

#################Setup 1 获取参数######################
##Volume:交易量
##high24hr: 43.15 最高价
##last:最新成交价
##low24hr:最低价
##percentChange:涨停百分比
##################N0.1 获取LTC当前行情###############
BASE_URL = 'https://data.gateio.life'
report = '/api2/1/ticker/ltc_usdt'
resp = requests.get(BASE_URL + report)
resp_json = resp.json()
print(resp_json)
volume = float(resp_json['quoteVolume'])
print(type(volume))
high24hr = float(resp_json['high24hr'])
# print(type(high24hr))
# print(high24hr)
last = float(resp_json['last'])
low24hr = float(resp_json['low24hr'])
percentChange = float(resp_json['percentChange'])
# exit()
################N0.2 获取K线#######################

BASE_URL = 'https://data.gateio.life/'
#
kline = 'api2/1/candlestick2/ltc_usdt?group_sec=600&range_hour=1' #在此处更改时间长度
# #
kline_url = BASE_URL + kline
print(kline_url)  # 打印网址
resp = requests.get(kline_url)
resp_json = resp.json()
data = resp_json['data']
# print(data)
df = pd.DataFrame(data, columns={'time': 0, 'volume': 1, 'close': 2, 'high': 3, 'low': 4, 'open': 5})
print(df)
print(df['time'])
timelist = df['time']
# 转换成localtime
timestamp = int(timelist[6])
print(timestamp)
timestamp = float(timestamp / 1000)
timearray = time.localtime(timestamp)
otherStyleTime = time.strftime("%Y-%m-%d %H:%M:%S", timearray)
print(otherStyleTime)
# exit()
#######################N0.3获取账户信息########################################
apiKey = 'EE426A45-AE79-47CC-AD41-39A30A70C0CB'
secret = 'f1c040267602e2b9cfe7c8d03078f39c222c80d0176db6910abb60874556b90a'  # Gate.io Key
gateio = ccxt.gateio({"apiKey": apiKey, 'secret': secret})
balance = gateio.fetch_balance()
# print(balance)
print(balance['LTC'])  # 获取账户余额

#####获取订单信息######
orders = gateio.fetch_orders('LTC/USDT')
print(len(orders))
print(orders)
print('order_id:' + str(orders[0]['id']))  ##注意顺序与网站是相反的
print('order_price:' + str(orders[0]['price']))
print('order_amount:' + str(orders[0]['amount']))
#####创建订单##########
# new_order = gateio.create_order(symbol='LTC/USDT', type='limit', side='buy', amount=0.085, price=43.02)##注意价格哦 sell是卖出
# print(new_order)

#####取消订单##########
# delete_order=gateio.cancel_order(id='', symbol='LTC/USDT')
# print(delete_order)
