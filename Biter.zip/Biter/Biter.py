BASEURL = 'https://api.huobi.pro' #must use this url
currencys = '/v1/common/currencys'

currencys_url = BASEURL + currencys
print(currencys_url)
import requests
import pandas as pd

resp = requests.get(currencys_url)
print(resp)
print(resp.status_code)
print(resp.json())
r_json = resp.json()
data = r_json['data']
# print(data)
# print()
for d in data: #获取币种
    print(d)
###############请求行情数据##############################################
pd.set_option('expand_frame_repr',False) #不让表格出现省略号
pd.set_option('display.max_rows',1000)
url= "https://api.huobi.pro/market/history/kline?period=30min&size=100&symbol=ltcusdt"
resp=requests.get(url)
print(resp)
print(resp.json())
resp_json=resp.json()
print(resp_json['status'])
data_list=resp_json['data']
df=pd.DataFrame(data_list)
print(df)
#请求 Ticker数据
symbol = 'ltcusdt'
url = 'https://api.huobi.pro' + '/market/detail/merged' + '?' + 'symbol=' + symbol
print(url)
resp = requests.get(url)
# print(resp.json())

ticker = resp.json()['tick']
print(ticker)

print(ticker['ask'])
print(ticker['bid'])

print("卖价：", ticker['ask'][0])
print("--"*10)
print("买家：", ticker['bid'][0])
