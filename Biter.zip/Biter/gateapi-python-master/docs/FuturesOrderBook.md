# FuturesOrderBook

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**asks** | [**list[FuturesOrderBookItem]**](FuturesOrderBookItem.md) | Asks order depth | 
**bids** | [**list[FuturesOrderBookItem]**](FuturesOrderBookItem.md) | Bids order depth | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


