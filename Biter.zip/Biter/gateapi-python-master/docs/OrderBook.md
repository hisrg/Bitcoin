# OrderBook

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**asks** | **list[list[str]]** | Asks order depth | 
**bids** | **list[list[str]]** | Bids order depth | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


