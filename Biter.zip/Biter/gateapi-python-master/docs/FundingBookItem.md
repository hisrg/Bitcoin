# FundingBookItem

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**rate** | **str** | Loan rate | [optional] 
**amount** | **str** | Borrowable amount | [optional] 
**days** | **int** | How long the loan should be repaid | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


