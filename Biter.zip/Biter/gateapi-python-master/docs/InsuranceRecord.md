# InsuranceRecord

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**t** | **int** | Unix timestamp in seconds | [optional] 
**b** | **str** | Insurance balance | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


