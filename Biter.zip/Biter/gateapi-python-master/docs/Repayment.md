# Repayment

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **str** | Loan record ID | [optional] 
**create_time** | **str** | Repayment time | [optional] 
**principal** | **str** | Repaid principal | [optional] 
**interest** | **str** | Repaid interest | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


