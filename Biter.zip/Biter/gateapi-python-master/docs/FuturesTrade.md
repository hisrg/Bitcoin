# FuturesTrade

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | Trade ID | [optional] 
**create_time** | **float** | Trading time | [optional] 
**contract** | **str** | Futures contract | [optional] 
**size** | **int** | Trading size | [optional] 
**price** | **str** | Trading price | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


