from __future__ import print_function
import gate_api
from gate_api.rest import ApiException

configuration = gate_api.Configuration()
#APIV4
configuration.key = 'e6b80dc97f9822ecdd46f143875b0552'
configuration.secret = 'e89387ba2ebc9bc16910d7a314d3bdb79fbc87c8e266e2b9ee95fa1c0be997be'
# uncomment the next line if using the API with another host
# configuration.host = 'https://some-other-host'
# configuration.proxy = 'http://localhost:1080'  # uncomment to proxy through a http proxy
# configuration.verify_ssl = False  # uncomment to turn off ssl verification
# More connection configuration is available in `Configuration` model.

# create an instance of the API class
api_instance = gate_api.FuturesApi(gate_api.ApiClient(configuration))
settle = 'btc' # str | Settle currency (default to 'btc')
order_id = '12345' # str | ID returned on order successfully being created

try:
    # Cancel a single order
    api_response = api_instance.cancel_futures_order(settle, order_id)
    print(api_response)
except ApiException as e:
    print("Exception when calling FuturesApi->cancel_futures_order: %s\n" % e)
# create an instance of the API class
api_instance = gate_api.FuturesApi(gate_api.ApiClient(configuration))
settle = 'btc' # str | Settle currency (default to 'btc')
contract = 'BTC_USD' # str | Futures contract, return related data only if specified (optional)
order = 12345 # int | Futures order ID, return related data only if specified (optional)
limit = 100 # int | Maximum number of record returned in one list (optional) (default to 100)
last_id = '12345' # str | Specify list staring point using the `id` of last record in previous list-query results (optional)

try:
    # List personal trading history
    api_response = api_instance.get_my_trades(settle, contract=contract, order=order, limit=limit, last_id=last_id)
    print(api_response)
except ApiException as e:
    print("Exception when calling FuturesApi->get_my_trades: %s\n" % e)